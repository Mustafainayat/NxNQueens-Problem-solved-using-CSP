/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csp;
import java.util.*;
/**
 *
 * @author Mustafa Inayat
 */
/**queen 1 = queen[0] in code
 * queen 2 = queen[1]
 * .
 * .
 * .
 * .
 * queen 8 = queen[7] in code
*/
//row number = queen number
//FOLLOWING CODE IS COMPILED ON NETBEANS IDE 10. PLEASE USE THE SAME VERSION OF IDE TO SUCCESSFULLY RUN THIS CODE, I DONT KNOW IF IT WILL WORK ON NEWER OR PREVIOUS VERSIONS
public class CSP {
    
    Domain []queen = new Domain[8];//8 queens and domain for each of them
    Grid chessboard = new Grid();//universal domain
    Grid []tempboard = new Grid [8];//used for backtracking
    int queensassigned = 0;//to check how many queens has been assigned
    public CSP()
    {
        for(int i = 0;i<8;i++)
        {
            queen[i]= new Domain();
        }
        for(int i = 0;i<8;i++)
        {
            tempboard[i] = new Grid();
        }
    }
    public int AssignRandomPosition()//random position generator
    {
        Random rand = new Random();
        return rand.nextInt(8);
    }
    public void PrintQueenDomains(int num)
    {
        System.out.print("Queen Number: ");
        System.out.println(num);
        for(int i = 0;i<8;i++)
        {
            System.out.print(this.queen[num].domain[i]);
            System.out.print(" ");
        }
        System.out.println();
    }
    public void AssignDomains()//assigining domains to queens everytime universal domain is changed
    {
        for(int x=0;x<8;x++)
        {
            System.arraycopy(chessboard.board[x], 0, queen[x].domain, 0, 8);
        }
    }
    public int CheckDomain(int x)//checking next queen's domain if there are any spots to place queen.. return 0 if no spot and return 1 if their is any spot left
    {
        int xcount = 0;
        for(int j = x;j<8;j++)
        {
            for(int i=0;i<8;i++)
            {
                if(queen[x].domain[i]=='x' || queen[x].domain[i]=='Q')
                {
                    xcount++;
                }
                else if (queen[x].domain[i]!='x')
                {
                    i = 100;
                    xcount = 0;
                }
            }
            if (xcount==8)
            {
                j = 100;
            }
        }
        if (xcount==8)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
    public void printtempgrid()
    {
        for (int i=0;i<8;i++)
        {
            System.out.println(i);
            for(int k = 0;k<8;k++)
            {
                for (int j=0;j<8;j++)
                {
                    System.out.print(this.tempboard[i].board[k][j]);
                    System.out.print(" ");
                }
                System.out.println();
            }
        }
    }
    public int getavailableposition(int x)//returns the first available position for next queen
    {
        int xcount=0;
        int pos=-1;
        for(int i=0;i<8;i++)
        {
            if(queen[x].domain[i]=='x' || queen[x].domain[i]=='Q')
            {
                xcount++;
            }
            else if (queen[x].domain[i]!='x')
            {
                pos = i;
                i = 100;
            }
        }
        if (xcount == 8)
        {
            return 0;
        }
        else
        {
            return pos;
        }
    }
    public int returnqueenposition(int queennum)//returns the position of previous queen placed on chessboard.
    {
        int j = -1;
        for(int i = 0;i<8;i++)
        {
            if (this.chessboard.board[queennum][i]=='Q')
            {
                j = i;
            }
        }
        return j;
    }
    public void copytempboard(int num)//pulling chessboard in previous version for backtracking
    {
        for(int i = 0;i<8;i++)
        {
            System.arraycopy(this.tempboard[num].board[i], 0, this.chessboard.board[i], 0, 8);
        }
    }
    public void rungame(Grid cb,int queennum, Grid tb[])//this is where all queens get assigned from 1-7
    {
        int x = queennum + 1;
        if(x<8)
        {
            int retval = this.CheckDomain(x);
            if (retval == 1)
            {
                int pos = this.getavailableposition(x);
                this.chessboard.ShrinkDomain(pos, x);
                this.chessboard.copychessboard(this.tempboard, x);
                this.queensassigned++;
                this.AssignDomains();
                rungame(this.chessboard,x,this.tempboard);

            }
            else if (retval == 0)
            {
                int j = this.returnqueenposition(queennum);
                this.copytempboard(queennum-1);
                this.chessboard.board[queennum][j] = 'x';
                this.queensassigned--;
                this.chessboard.copychessboard(this.tempboard, queennum-1);
                this.AssignDomains();
                rungame(this.chessboard,queennum-1,this.tempboard);
            }
        }
    }
    
    public static void main(String[] args) 
    {
        CSP game = new CSP();
        int randpos = game.AssignRandomPosition();
        game.AssignDomains();
        game.chessboard.ShrinkDomain(randpos, 0);
        game.chessboard.copychessboard(game.tempboard, 0);
        game.AssignDomains();
        game.queensassigned++;
        game.rungame(game.chessboard, 0, game.tempboard);
        System.out.println("Solution: ");
        game.chessboard.PrintGrid();
        
    }
    
}
