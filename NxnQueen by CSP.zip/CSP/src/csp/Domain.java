/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csp;

public class Domain {
    char []domain = new char[8];//domain for each queen
    public Domain()
    {
        for(int i = 0;i<8;i++)
        {
            domain[i]= '-';
        }
    }
  
}
