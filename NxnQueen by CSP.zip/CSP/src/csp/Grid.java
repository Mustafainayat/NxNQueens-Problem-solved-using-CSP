/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csp;

public class Grid {
    
    char [][] board = new char [8][8];//board of 8x8
    
    public Grid()
    {
        for (int i=0;i<8;i++)
        {
            for (int j=0;j<8;j++)
            {
                this.board[i][j] = '-';
            }
        }
    }
    public void copychessboard(Grid tempb[],int num)//saving the current chessboard situation in temporary board for backtracking when no domain is left.
    {
        for(int i = 0;i<8;i++)
        {
            System.arraycopy(this.board[i], 0, tempb[num].board[i], 0, 8);
        }
    }
    
    public void ShrinkDomain(int col, int row)//assigning queens to (row,col) position in chessboard and shrinking down the domains for other queens.
    {
        int r = 0;
        int c = 0;
        this.board[row][col] = 'Q';
        r=row;
        c=col;
        for (int i = 0;i<8;i++)
        {
            r++;
            if ((r>7) || (c>7))
            {
                i = 9;
            }
            if ((r<0) || (c<0))
            {
                i = 9;
            }
            else if (((r<8) && (c<8)) && ((r>-1) && (c>-1)))
            {
                this.board[r][c] = 'x';
            }
        }
        r=row;
        c=col;
        for (int i = 0; i <8;i++)
        {
            r++;
            c++;
            if ((r>7) || (c>7))
            {
                i = 9;
            }
            if ((r<0) || (c<0))
            {
                i = 9;
                
            }
            else if (((r<8) && (c<8)) && ((r>-1) && (c>-1)))
            {
                this.board[r][c] = 'x';
            }
        }
        r=row;
        c=col;
        for (int i = 0; i <8;i++)
        {
            r++;
            c--;
            if ((r>7) || (c>7))
            {
                i = 9;
            }
            if ((r<0) || (c<0))
            {
                i = 9;
            }
            else if (((r<8) && (c<8)) && ((r>-1) && (c>-1)))
            {
                this.board[r][c] = 'x';
            }
        }
        this.PrintGrid();
    }
    public void PrintGrid()//printing grid
    {
        for(int i = 0;i<8;i++)
        {
            for(int j = 0;j<8;j++)
            {
                System.out.print(this.board[i][j]);
                System.out.print("\t");
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
    }
    
}
